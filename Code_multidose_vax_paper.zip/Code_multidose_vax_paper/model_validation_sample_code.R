#Load libraries
library(INLA)
INLA:::inla.dynload.workaround()
#This is an example validation script for DTP1 using the CP method

library(raster); library(maptools)
library(gtools); library(sp); library(spdep)
library(rgdal)
library(ggplot2)

#Create file paths
filePathData <- "/.../"
filePathData1 <- "/.../"
filePathData2 <- "/.../"

#loading the data
vaxdata <- read.csv(paste0(filePathData,"....csv"), header=TRUE) #Vaccination coverage data
vaxcov  <- read.csv(paste0(filePathData,"....csv"),header=TRUE) #Covariate data

#Align both data sets using DHS cluster IDs
data.merge <- merge(vaxdata, vaxcov, by="DHSCLUST")

vaxcov.all  <- data.merge[,19:26]   #Covariate data including lon-lat coordinates 
vaxdata.all <- data.merge[,3:17]    #Vaccination coverage data

#Delete clusters where the total no of childlren sampled is zero or 1
zero.clust <- which(is.na(vaxdata.all$total)|vaxdata.all$total<=1)
if (length(zero.clust)>0){
  vaxdata.all <- vaxdata.all[-zero.clust,]
  vaxcov.all  <- vaxcov.all[-zero.clust,]
}

#Example using DTP1
Numvacc.all    <- vaxdata.all$dtp1_count
weights.all    <- vaxdata.all$total

#Coordinates
coords.all    <- cbind(vaxdata.all$LONGNUM,vaxdata.all$LATNUM)

set.seed(500)

#######################################################
#Start k-fold cross-validation loop
cv <- 10   #10-fold cross validation
lim <- floor(nrow(coords.all)/cv)

srand <- sample(1:nrow(coords.all),nrow(coords.all), replace=FALSE)

val.out <- matrix(0, cv, 4) 

for (kk in 1:cv){
 if (kk < cv) {qq <- (((kk-1)*lim)+1):(lim*kk); samp.c <- srand[qq]}
 if (kk == cv) {qq <- (((kk-1)*lim)+1):nrow(coords.all); samp.c <- srand[qq]}

#Validation data 
coords.nc 	<- coords.all[samp.c,]
Numvacc.nc	<- Numvacc.all[samp.c]
weights.nc	<- weights.all[samp.c]
vaxcov.nc	<- vaxcov.all[samp.c,]
yp.nc=np.nc=rep(NA, length(Numvacc.nc))

#Model fitting data
coords  <- coords.all[-samp.c,]
Numvacc <- Numvacc.all[-samp.c] 
weights <- weights.all[-samp.c]
vaxcov  <- vaxcov.all[-samp.c,]

#Covariates
#Model-fitting
xp1     <- vaxcov$educ.prop
xp2     <- vaxcov$religion.prop
xp3	<- vaxcov$sba.prop
xp4	<- vaxcov$l_n66_pigs_density_mean
xp5	<- vaxcov$URBAN_RURAL1
xp6     <- vaxcov$l_n28_viirs_nightlights_mean
xp7     <- vaxcov$wealth.prop 
xp8     <- vaxcov$n95_proximity_national_borders_mean 

#Validation
xv1     <- vaxcov.nc$educ.prop
xv2     <- vaxcov.nc$religion.prop
xv3	<- vaxcov.nc$sba.prop
xv4	<- vaxcov.nc$l_n66_pigs_density_mean
xv5	<- vaxcov.nc$URBAN_RURAL1
xv6     <- vaxcov.nc$l_n28_viirs_nightlights_mean
xv7     <- vaxcov.nc$wealth.prop 
xv8     <- vaxcov.nc$n95_proximity_national_borders_mean 

#Admin0 shapefile for Nigeria
shp_ng  <- readShapePoly(paste0(filePathData1,"gadm36_NGA_0.shp"))

#meshfit: fine triangulated mesh
shp_df <- fortify(shp_ng)
shp.bnd <- cbind(shp_df$long, shp_df$lat)
c.bnd <- as.matrix(shp.bnd)	
meshfit <- inla.mesh.2d(loc=coords,loc.domain=c.bnd, max.edge=c(0.05, 0.6),cutoff=0.1)			

#For priors
r0 <- 0.48 #This is 5% of the extent of Nigeria in the north-south direction (i.e. 0.05*(ymax-ymin))
nu <- 1 #Matern smoothness parameter, redundant here as it implies alpha=2
alpha <- 2

#Matern SPDE model object using inla.pcmatern
spde <- inla.spde2.pcmatern(mesh=meshfit, alpha=alpha, prior.range=c(r0, 0.01), prior.sigma=c(3, 0.01))

#Observation points
X0 <- model.matrix(~ -1 + xp1 + xp2 + xp3 + xp4 + factor(xp5) + xp6 + xp7 + xp8)

Xobs <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(xp5)0"))])

colnames(Xobs) <- c("x1", "x2", "x3", "x4", "x5_1", "x6", "x7", "x8")
Ap.i <- inla.spde.make.A(mesh=meshfit, loc=coords)
lp.i = rep(1,length(xp1))
stk.point <- inla.stack(tag='point',
                        data=list(y=Numvacc,n=weights),
                        A=list(Ap.i,1,1,1),
                        effects=list(s=1:spde$n.spde, rr=1:length(weights), intercept=rep(1, length(xp1)), Xobs)) 

#Validation points - not used for model-fitting
X0 <- model.matrix(~ -1 + xv1 + xv2 + xv3 + xv4 + factor(xv5) + xv6 + xv7 + xv8)

Xval <-  as.data.frame(X0[,-which(colnames(X0)%in%c("factor(xv5)0"))])

colnames(Xval) <- c("x1", "x2", "x3", "x4", "x5_1", "x6", "x7", "x8")
Aval <- inla.spde.make.A(mesh=meshfit, loc=coords.nc)
lval = rep(1,length(xv1))
stk.val <- inla.stack(tag='val',
                      data=list(y=yp.nc,n=np.nc),
                      A=list(Aval,1,1,1),
                      effects=list(s=1:spde$n.spde, rr=(length(weights)+1):(length(weights)+length(xv1)), intercept=rep(1, length(xv1)), Xval)) #NOTE

# Stack
stk.full <- inla.stack(stk.point)  #Note no stk.val

# Fit model
#Additional priors
hyper.prec = list(theta = list(prior="pc.prec", param=c(3,0.01)))
control.fixed = list(mean=0, prec=1/1000, mean.intercept=0, prec.intercept=1/1000)   

formula  <- y ~ -1 + intercept + x1 + x2 + x3 + x4 + x5_1 + x6 + x7 + x8 + f(s, model=spde) + f(rr, model="iid", hyper = hyper.prec) 
res <- inla(formula, data=inla.stack.data(stk.full), family="binomial", 
            Ntrials = stk.full$data$data$n,
            control.predictor=list(compute=TRUE, A=inla.stack.A(stk.full), link=1),
            control.compute=list(dic=TRUE, config = TRUE, waic=TRUE),
            control.fixed=control.fixed)

#save model
save(res, file=paste0(filePathData1,"model.rda"))

spde.result <- inla.spde2.result(inla=res,name="s",spde=spde)


##################POSTERIOR SAMPLING
nsamp <- 1000

#Posterior sampling
ps <- inla.posterior.sample(nsamp, res) 
contents <- res$misc$configs$contents

#ID for spatial random effect
idSpace <- contents$start[which(contents$tag=="s")]-1 +
  (1:contents$length[which(contents$tag=="s")])

#ID for iid effects
idR <- contents$start[which(contents$tag=="rr")]-1 +
  (1:contents$length[which(contents$tag=="rr")])

#ID for fixed effects
idX <- contents$start[which(contents$tag=="intercept")]-1 + (1:9) # fixed effects, 9 = no of regression coefficients

# extract samples 
xLatent <- matrix(0, nrow=length(ps[[1]]$latent), ncol=nsamp) 
xHyper <- matrix(0, nrow=length(ps[[1]]$hyperpar), ncol=nsamp) 
for(i in 1:nsamp){
  xLatent[,i] <- ps[[i]]$latent
  xHyper[,i] <- ps[[i]]$hyperpar
}
xSpace <- xLatent[idSpace,]
XR <- xLatent[idR,]
xX <- xLatent[idX,]

# construct predictions

#Validation
#Draw samples for IID term
sample.IIDval <- matrix(0, length(xv1),  nsamp)
for (i in 1:nsamp){
  ID.precision <- xHyper[3,i]              #the 3rd row contains precision for rr; same as ps[[i]]$hyperpar[3]
  ID.sigma <- ID.precision^-0.5
  sample.IIDval[, i] <- rnorm(length(xv1), sd=ID.sigma)
}

linpred     <- as.matrix(Aval %*% xSpace + as.matrix(cbind(1, Xval)) %*% xX + sample.IIDval)
inv.linpred <- inv.logit(linpred) 
pred.val    <- data.frame(t(apply(inv.linpred, 1, FUN=function(x){ c(mean(x), sd(x), quantile(x, probs=c(0.025,0.5,0.975)))}))) 
colnames(pred.val) <- c("mean", "sd", "0.025quant", "0.5quant", "0.975quant")
fitted.mean.val <- as.vector(data.matrix(as.vector(pred.val["mean"])))
fitted.low.val  <- as.vector(data.matrix(as.vector(pred.val["0.025quant"])))
fitted.up.val   <- as.vector(data.matrix(as.vector(pred.val["0.975quant"])))

prob.val <- Numvacc.nc/weights.nc

#Calculate validation statistics
corr <- cor(fitted.mean.val,prob.val)
rsq.val  <- (cor(fitted.mean.val,prob.val))^2
RMSE.val <- sqrt(sum((fitted.mean.val-prob.val)^2)/length(prob.val))
avg_bias <- sum(fitted.mean.val-prob.val)/length(prob.val)
#count <- 0
#for(r in 1:length(prob.val)){
#  if ((prob.val[r] >= fitted.low.val[r]) && (prob.val[r] <= fitted.up.val[r])) count <- count + 1
#}
#cov.rate.val <- (count/length(prob.val))*100

val.out[kk, ] <- c(corr, rsq.val, RMSE.val, avg_bias)
print(val.out[kk, ])
}

colnames(val.out) <- c("correl", "rsq.val", "RMSE.val", "avg_bias")
write.csv(val.out, paste0(filePathData2, "val_out_dtp1_rand.csv"))
