#R script for data extraction - DTP1, DTP2, DTP3 and all inidcators needed for the CP approach
#The remaining indicators for the RB approach were calculated in excel from these.

library(foreign)
library(dplyr)
setwd("......")
data = read.dta(".../NGKR7AFL.DTA", convert.factors=FALSE) #DHS child file (STATA version)

#List and select variable names
#List of variables to extract

#Cluster and Interview
#v001 - Cluster_number; v006 - month_of_interview; v007 - year_of_interview; 
#v016 - day of interview	

#Child variables
#hw1 - child's age in months; b1 - month of birth; b2 - year of birth; b3 - date of birth (cmc)

#DTP
#h3 - received dpt 1; h3d h3m h3y - dpt 1 day, month, year	
#h5 - received dpt 2; h5d h5m h5y - dpt 2 day, month,	year
#h7 - received dpt 3; h7d h7m h7y - dpt 3 day, month, year 

# s1508d1 s1508d2 s1508d3 - received dpt 1	received dpt 2	received dpt 3
# sd1508d1 sd1508d2 sd1508d - dpt 1 day	dpt 2 day	dpt 3 day
# sm1508d1 sm1508d2 sm1508d3 - dpt 1 month dpt 2 month dpt 3 month	
# sy1508d1 sy1508d2 sy1508d3 - dpt 1 year	dpt 2 year	dpt 3 year

vars1 = c("v001", "v006", "v007", "v016", "hw1", "b1", "b2", "b3", "h3", "h3d", "h3m", "h3y", "h5",
          "h5d", "h5m", "h5y", "h7", "h7d", "h7m", "h7y")

#DTP
data.D.ext = data[vars2]
head(data.D.ext)

#Exclusion of rows with missing vaccination data
data.D.ext = data.D.ext[!is.na(data.D.ext$h3),]
data.D.ext = data.D.ext[!is.na(data.D.ext$h5),]
data.D.ext = data.D.ext[!is.na(data.D.ext$h7),]

vacc.D1 = data.D.ext$h3; del1 = which(vacc.D1==8) #don't know=8
if (length(del1)>0)data.D.ext = data.D.ext[-del1,]
vacc.D2 = data.D.ext$h5; del2 = which(vacc.D2==8)
if (length(del2)>0) data.D.ext = data.D.ext[-del2,]
vacc.D3 = data.D.ext$h7; del3 = which(vacc.D3==8)
if (length(del3)>0) data.D.ext = data.D.ext[-del3,]

#Calculation of child's age in months

#DTP
xx1 = data.D.ext$v006 - data.D.ext$b1     #month.int - month.birth
yy1 = data.D.ext$v007 - data.D.ext$b2     #year.int - year.birth
age.D = 12*yy1 + xx1
data.D.ext$age.D = age.D


#Further Processing and writing of files - DTP
vars.2 = c("v001", "age.D", "h3", "h5", "h7")
data.D = data.D.ext[vars.2]

#Delete category "9"
del1 = which(data.D$h3==9|data.D$h5==9|data.D$h7==9)
if (length(del1)>0) data.D = data.D[,-del1]

l4 = which(data.D$h3==0); l5 = which(data.D$h3!=0) #no=0
vacc.num.D = 1:nrow(data.D); vacc.num.D[l4]=0; vacc.num.D[l5]=1 
data.D$received_dtp1 = vacc.num.D

l4 = which(data.D$h5==0); l5 = which(data.D$h5!=0) #no=0
vacc.num.D = 1:nrow(data.D); vacc.num.D[l4]=0; vacc.num.D[l5]=1 
data.D$received_dtp2 = vacc.num.D

l4 = which(data.D$h7==0); l5 = which(data.D$h7!=0) #no=0
vacc.num.D = 1:nrow(data.D); vacc.num.D[l4]=0; vacc.num.D[l5]=1 
data.D$received_dtp3 = vacc.num.D
colnames(data.D) = c("DHSCLUST", "childs_age_in_months", "received_dtp1_ch", 
                     "received_dtp2_ch", "received_dtp3_ch", "received_dtp1", "received_dtp2", "received_dtp3")

head(data.D)

#Re-assign inconsistent records
for (i in 1:nrow(data.D)){
  if(data.D$received_dtp1[i]==0 && data.D$received_dtp2[i]==0 && data.D$received_dtp3[i]==1){print(i)
    data.D$received_dtp1[i] <- 1; data.D$received_dtp3[i] <- 0}
  
  if(data.D$received_dtp1[i]==0 && data.D$received_dtp2[i]==1 && data.D$received_dtp3[i]==0){print(i)
    data.D$received_dtp1[i] <- 1; data.D$received_dtp2[i] <- 0}
  
  if(data.D$received_dtp1[i]==0 && data.D$received_dtp2[i]==1 && data.D$received_dtp3[i]==1){print(i)
    data.D$received_dtp1[i] <- 1; data.D$received_dtp3[i] <- 0}
  
  if(data.D$received_dtp1[i]==1 && data.D$received_dtp2[i]==0 && data.D$received_dtp3[i]==1){print(i)
    data.D$received_dtp2[i] <- 1; data.D$received_dtp3[i] <- 0}
}

data.D[data.D$DHSCLUST==675,]

#Subset to children aged 12-23m
data.D.12.23 <- subset(data.D, childs_age_in_months>=12 & childs_age_in_months<=23)


#Cluster counts for DTP1, 2 and 3
Summary_all <- group_by(data.D.12.23, DHSCLUST) %>% 
  summarize(total = n(),
            dtp1_count = sum(received_dtp1, na.rm = TRUE),
            dtp1_prop = dtp1_count/total,
            dtp2_count = sum(received_dtp2, na.rm = TRUE),
            dtp2_prop = dtp2_count/total,
            dtp3_count = sum(received_dtp3, na.rm = TRUE),
            dtp3_prop = dtp3_count/total)
head(Summary_all)


#DTP2|1
data.D.12.23.1 <-  subset(data.D.12.23, received_dtp1==1)
Summary_2_1 <- group_by(data.D.12.23.1, DHSCLUST) %>% 
  summarize(total_2_1 = n(),
            dtp2_1_count = sum(received_dtp2, na.rm = TRUE),
            dtp2_1_prop = dtp2_1_count/total_2_1)
head(Summary_2_1)


#DTP3|2
data.D.12.23.1.2 <-  subset(data.D.12.23, received_dtp1==1 & received_dtp2==1)
Summary_3_2 <- group_by(data.D.12.23.1.2, DHSCLUST) %>% 
  summarize(total_3_2 = n(),
            dtp3_2_count = sum(received_dtp3, na.rm = TRUE),
            dtp3_2_prop = dtp3_2_count/total_3_2)
head(Summary_3_2)

dat.merge1 <- merge(Summary_all, Summary_2_1, by = "DHSCLUST", all.x = TRUE)
dat.merge <- merge(dat.merge1, Summary_3_2, by = "DHSCLUST", all.x = TRUE)

#Add lon-lat locations
lonlat <- read.csv("... .csv", header = TRUE)
lonlat <- lonlat[,c("DHSCLUST", "LATNUM", "LONGNUM")]
lonlat <- lonlat[,2:4]

dat.merge.new <- merge(dat.merge, lonlat, by = "DHSCLUST", all.x = TRUE)

write.csv(dat.merge.new, "DTP_cluster_data_12_23.csv")  
