#Example R script for covariate selection using the CP approach

#Load libraries
library(Metrics)
library(plyr)
library(xtable)
library(MASS)
require(dplyr) 
library(car)
library(gtools)
library(raster)

set.seed(500)

#Set working directory
setwd("//worldpop.files.soton.ac.uk/worldpop/Projects/WP516374_VaxPop/Working/DHS_2018_data")

#Covariates used
cov_names <- c(
#Geospatial
"n2_cattle_density_mean", "n3_chickens_density_mean", 
"n4_goats_density_mean", "n66_pigs_density_mean", "n67_sheep_density_mean",
"n12_dst_edge_cultivated_areas_mean",
"n27_urbanaccessibility_2015_mean",
"n28_viirs_nightlights_mean",
"n80_UCDP_DistanceToConflicts_mean",
"n92_avg_aridity_2013_2018_mean",
"n93_avg_precip_2013_2018_mean",
"n94_avg_number_WetDays_2013_2018_mean",
"n95_proximity_national_borders_mean",
"n98_avg_modis_EVI_2013_2018_mean",
"n99_avg_modis_daytime_landsurface_temp_2013_2018_mean",
"n103_srtm_slope_mean",
"n104_traveltime_to_HF_providing_RI_mean",
#Kriged covariates
"wealth.prop",
"educ.prop",
"media.prop",
"religion.prop",
"sba.prop",
"URBAN_RURAL1") #could drop sba.prop

#Read pre-processed data sets
covs_geos <- read.csv("NEW_DTP_covariates/Nigeria_Extractions_June2020_MostRecent.csv", header = TRUE) 
covs_DHS <- read.csv("NEW_DTP_covariates/DHS_covariates_cluster_selected.csv", header = TRUE) 
covs_UR <- read.csv("NEW_DTP_covariates/DHS_urban_rural.csv", header = TRUE) #Urban-rural covariate data 
vaxdat <- read.csv("NEW_DTP1_cluster_data_12_23.csv", header=TRUE) #Vaccination data


#Convert urban-rural covariate to numeric
covs_UR$URBAN_RURAL1 <- as.factor(covs_UR$URBAN_RURAL)
covs_UR$URBAN_RURAL1 <- as.numeric(covs_UR$URBAN_RURAL1)
covs_UR$URBAN_RURAL1[covs_UR$URBAN_RURAL1==1] <- 0
covs_UR$URBAN_RURAL1[covs_UR$URBAN_RURAL1==2] <- 1


#Merge covariate data sets
cov <- merge(covs_geos, covs_DHS, by = "DHSCLUST", all.x = TRUE)
cov <- merge(cov, covs_UR, by = "DHSCLUST", all.x = TRUE)

cov_names1 <- c("DHSCLUST", "LATNUM", "LONGNUM", cov_names)
covs <- cov[,cov_names1]

#Align covariate and vaccination coverage data using DHS cluster numbers
data.merge <- merge(vaxdat, covs, by="DHSCLUST", all.x = TRUE)

#Delete rows with missing covariate values
del <- numeric(nrow(data.merge))
for (i in 1:nrow(data.merge)){
  if (any(is.na(data.merge[i,21:43]))) del[i] <- i
}
if (length(which(del!=0))>0) data.merge <- data.merge[-which(del!=0),]     

#Separate covariate and vaccination coverage data
covs <- data.merge[,21:ncol(data.merge)]
vaxdat <- data.merge[,1:20]

names(covs)
names(vaxdat)

#Vaccination data
#DTP1
TotChild <- vaxdat$total # Total number of children surveyed in each cluster
TotVax   <- vaxdat$dtp1_count # Number of children vaccinated

#Un-comment these when running for other indicators
#DTP2|1
#TotChild <- vaxdat$total_2_1 # Total number of children surveyed in each cluster
#TotVax   <- vaxdat$dtp2_1_count # Number of children vaccinated

#DTP3|2
#TotChild <- vaxdat$total_3_2_1 # Total number of children surveyed in each cluster
#TotVax   <- vaxdat$dtp3_2_1_count # Number of children vaccinated

#Delete NA clusters or clusters where no child was sampled
zero.clust <- which(is.na(TotChild)|TotChild==0)
if (length(zero.clust)>0){
  TotChild <- TotChild[-zero.clust]
  TotVax   <- TotVax[-zero.clust]
  vaxdat <- vaxdat[-zero.clust,]
  covs  <- covs[-zero.clust,]
}

#Use edited cluster coordinates in the covariates file
vaxcoord <- vaxdat[,c(18,17)]
head(vaxcoord)

#Covariates
covars <- covs

############################################################
#Histograms
#par(mfrow=c(2,5))
#for (i in 1:10){
#  hist(covars[,i], main = names(covars)[i])
#}
#windows()
#par(mfrow=c(2,5))
#for (i in 11:20){
# hist(covars[,i], main = names(covars)[i])
#}
#windows()
#par(mfrow=c(2,5))
#for (i in 21:23){
#  hist(covars[,i], main = names(covars)[i])
#}
#par(mfrow=c(1,3))
#for (i in 31:35){
#hist(covars[,i], main = names(covars)[i])
#}

##############################################################

#Take logs of heavily skewed covariates
llog <- c(1:5,7:10,16,17)
for (i in 1:length(llog)){
  covars[,llog[i]] <- log(covars[,llog[i]] + 0.05) #0.05 > min value
  #if(i==2) covars[,llog[i]] <- log(covars[,llog[i]] + 4.0)
  #if(i==10) covars[,llog[i]] <- log(covars[,llog[i]] + 0.15)
  names(covars)[llog[i]] <- paste0("l_",names(covars)[llog[i]])
}


##############################################################
#Linearity checks
#pp = TotVax/TotChild
#pp[pp==0] <- 0.001
#pp[pp==1] <- 0.99
#windows()
#par(mfrow=c(2,5))
#for (i in 1:10){
#  plot(covars[,i],logit(pp), main = names(covars)[i], ylab="logit(Probability)", xlab="")
#  abline(lm(logit(pp)~covars[,i]))
#}

#windows()
#par(mfrow=c(2,5))
#for (i in 11:20){
#  plot(covars[,i],logit(pp), main = names(covars)[i], ylab="logit(Probability)", xlab="")
#  abline(lm(logit(pp)~covars[,i]))
#}

#windows()
#par(mfrow=c(2,5))
#for (i in 21:23){
#  plot(covars[,i],logit(pp), main = names(covars)[i], ylab="logit(Probability)", xlab="")
#  abline(lm(logit(pp)~covars[,i]))
#}
###############################################################

#Declare binary/categorical covariates as factors
covars <- data.frame(covars)
covars <- within(covars, {
  URBAN_RURAL1 <- factor(URBAN_RURAL1)
})


#-------------------------Covariate selection starts here--------------------#
#Single covariate models first
Data <- cbind(TotChild, TotVax, covars)

Data.1 <- Data[,-1]  #Delete TotChild for model
covlist <- names(Data.1)
covlist=covlist[-grep("TotVax", covlist)]

#Rank the covariates by fitting single Covariate models
#Monte Carlo cross-validation exercise repeated n.iter times
AICs=dev=nulldev=n.par=r2=pr2=iter=numeric()
model=response=character()
n.iter=5
propsub=0.8
resp="cbind(TotVax, TotChild-TotVax)"
resp1 = "TotVax"
weights = "TotChild"

for(i in 1:n.iter){
  subind=sample(1:nrow(Data), propsub*nrow(Data), replace=F)
  subdat=Data[subind,]
  preddat=Data[-subind,]
  ## the null model, for comparison
  nullmod=glm(formula(paste(resp, "~1")), data=Data, family = binomial(logit))
  for(j in covlist){
    form=formula(paste(resp, "~", j))
    pmod=glm(form, data=subdat, family = binomial(logit))
    fullmod=glm(form, data=Data, family = binomial(logit))
    ## pr2 checks the predictive power of the model against a 'new' subset of the data
    pr2=c(pr2,cor(pmod$fitted, subdat[[resp1]]/subdat[[weights]])^2) 
    ## AIC for the model on the full data
    AICs=c(AICs, AIC(fullmod))
    dev=c(dev, deviance(fullmod))
    n.par=c(n.par,1)
    iter=c(iter,i)
    r2=c(r2,cor(fullmod$fitted, Data[[resp1]]/Data[[weights]])^2) 
    model=c(model,j)
    response=c(response, resp1)
    #print(paste(i, j, sep="X"))
  }
}
op=data.frame(model, response, dev, AICs, r2, pr2, n.par )
singles=ddply(op, .(model), summarise,
              model=model[1],
              response=response[1],
              dev=dev[1],
              pr2=mean(pr2),
              AICs=AICs[1],
              r2=r2[1])

### Add deviance reduction
singles$devred=singles$dev/deviance(nullmod)

## order by AICs (but could be devred or pr2)
#singles=singles[order(singles$AICs),]

## order by pr2
singles <- singles[order(singles$pr2, decreasing=TRUE),]
keepsingles <- singles   #can decide which single covariates to keep at this stage

#Ranks
singles <- within(singles, ranks <- 1:nrow(singles))

#Covariates and ranks
cov.rank <- data.frame(covariate=as.character(singles$model), ranks = singles$ranks)

#Output file 1
#write.csv(singles, file="Single.Cov.Models.csv")
#####End of single covariate models

#################################################################################


#Separate categorical covariates before this step
covars.old <- covars  #Keep old covars
covars <- covars[,-c(23)]  #Remove urban rural


##Detection of multicollinearity through correlations between covariates and VIF analysis

#Correlations
#Determine correlations between the covariates and extract highly correlated pairs for screening and elimination. 
#Flag covariate pairs with correlations >= 0.8   #can change to a different value

corrs <- cor(covars[,-1])
bigcors <- matrix(0,1, 2) 
for (i in 2: nrow(corrs)){
  for (j in 1:(i-1)){
    if (abs(corrs[i,j])>=0.8) bigcors <- rbind(bigcors, c(i,j))  #Note 0.8 cutoff
  }
}

bigcors <- bigcors[-1,]
bigcors.dat <- matrix(0, nrow(bigcors), 3)
for (i in 1:nrow(bigcors)){
  bigcors.dat[i,] <- c(rownames(corrs)[bigcors[i,1]],colnames(corrs)[bigcors[i,2]], 
                       round(corrs[bigcors[i,1],bigcors[i,2]],3))
}

#Pairs of covariates with high correlations
bigcors.dat

#Select between pairs of highly correlated covariates using their ranks
all.covs <-rownames(corrs)
for (i in 1:nrow(bigcors.dat)){
  name.cov <- bigcors.dat[i,1:2]
  if (name.cov[1]%in%all.covs && name.cov[2]%in%all.covs){
    r1 <- which(cov.rank$covariate==name.cov[1])
    r2 <- which(cov.rank$covariate==name.cov[2])
    if (r1>r2) all.covs <- all.covs[-which(all.covs==name.cov[2])]
    if (r2>r1) all.covs <- all.covs[-which(all.covs==name.cov[1])]
  }
}

#Check that all remaining covariates are not highly correlated
corrs  <- cor(covars[,all.covs])
corrs

covars.1      <- covars[,all.covs]
sel.cov.names <- names(covars.1)

#Selected covariates from singles 
singles1 <- singles[singles$model %in% sel.cov.names,]

#VIF analysis using the remaining covariates
covnames <- as.character(singles1$model)
Data <- cbind(TotChild, TotVax, covars.1)
head(Data)
form    <- paste("cbind(TotVax, TotChild-TotVax)","~", paste(covnames, collapse=" + "))
mod.vif <- glm(form, data=Data, family = binomial(logit))
summary(mod.vif)
vif(mod.vif)


#####################################################################################
#Reconstitute "Data" to include categorical covariates for model selection
all.covs <- c(all.covs,names(covars.old)[c(23)])
covars.1      <- covars.old[,all.covs]
Data <- cbind(TotChild, TotVax, covars.1)


#Define categorical variables as factors
Data <- data.frame(Data)
Data <- within(Data, {
  URBAN_RURAL1 <- factor(URBAN_RURAL1)
})
covnames <- as.character(all.covs)

#Do a second VIF check
form    <- paste("cbind(TotVax, TotChild-TotVax)","~", paste(covnames, collapse=" + "))
mod.vif <- glm(form, data=Data, family = binomial(logit))
summary(mod.vif)
vif(mod.vif)


########################## 
#StepAIC regression - k=2 penatly
n <- nrow(Data)
form <- paste("cbind(TotVax, TotChild-TotVax)","~", paste(covnames, collapse=" + "))
fit  <- glm(form, data = Data, family = binomial(logit))
mod.step1 <- stepAIC(fit, trace=FALSE, direction = "backward") #Note penalty  #, k = log(n)
summary(mod.step1) #AIC: 3791.1
vif(mod.step1)

#Correlation
#plot(Data$TotVax/Data$TotChild, fitted(fit))
#cor(Data$TotVax/Data$TotChild, fitted(fit))

########################## 
#StepAIC regression - k=log(n) penatly
fit  <- glm(form, data = Data, family = binomial(logit))
mod.step2 <- stepAIC(fit, trace=FALSE, direction = "backward", k = log(n)) #Note penalty
summary(mod.step2) 
vif(mod.step2)


#Selected covariates
covout <- c("educ.prop",
            "religion.prop",
            "sba.prop",
            "l_n66_pigs_density_mean",
            "URBAN_RURAL1",
            "l_n28_viirs_nightlights_mean",
            "wealth.prop",
            "n95_proximity_national_borders_mean")

Data.out <- Data[,covout]
Data.out$DHSCLUST <- vaxdat$DHSCLUST
Data.out$lon <- vaxcoord$LONGNUM
Data.out$lat <- vaxcoord$LATNUM

write.csv(Data.out, "...DTP_covariates_selected.csv")





